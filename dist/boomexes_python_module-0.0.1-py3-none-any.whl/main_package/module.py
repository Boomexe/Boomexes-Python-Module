def say_hello(name):
    return f'Hello, {name}!'

def add_numbers(num1, numb2):
    return num1 + numb2