import random

def say_hello(name):
    return f'Hello, {name}!'

def add_numbers(num1, numb2):
    return num1 + numb2

def return_random_chance(a, b):
    return random.randint(a, b) == a